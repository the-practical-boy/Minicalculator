package com.example.minicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity {
    ImageView[] btn =new ImageView[10];
    ImageView btn_multiply,btn_divide,btn_plus,btn_minus,btn_start,btn_end,btn_ac,btn_equal,btn_dot;
    TextView input,answer;
    String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input=findViewById(R.id.input);
        answer=findViewById(R.id.answer);

        btn[0]=findViewById(R.id.button_0);
        btn[1]=findViewById(R.id.button_1);
        btn[2]=findViewById(R.id.button_2);
        btn[3]=findViewById(R.id.button_3);
        btn[4]=findViewById(R.id.button_4);
        btn[5]=findViewById(R.id.button_5);
        btn[6]=findViewById(R.id.button_6);
        btn[7]=findViewById(R.id.button_7);
        btn[8]=findViewById(R.id.button_8);
        btn[9]=findViewById(R.id.button_9);
        btn_ac=findViewById(R.id.button_ac);
        btn_divide=findViewById(R.id.button_divide);
        btn_dot=findViewById(R.id.button_dot);
        btn_end=findViewById(R.id.button_end_bracket);
        btn_start=findViewById(R.id.button_start_bracket);
        btn_equal=findViewById(R.id.button_equal);
        btn_minus=findViewById(R.id.button_minus);
        btn_multiply=findViewById(R.id.button_multiply);
        btn_plus=findViewById(R.id.button_plus);

        btn[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"0");
            }
        });btn[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"1");
            }
        });btn[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"2");
            }
        });btn[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"3");
            }
        });btn[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"4");
            }
        });btn[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"5");
            }
        });btn[6].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"6");
            }
        });btn[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"7");
            }
        });btn[8].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"8");
            }
        });btn[9].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"9");
            }
        });
        btn_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"+");
            }
        });
        btn_dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+".");
            }
        });
        btn_multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"x");
            }
        });
        btn_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"-");
            }
        });
        btn_divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText(data+"/");
            }
        });
        btn_ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                input.setText("");
                answer.setText("");
            }
        });

        btn_equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data=input.getText().toString();
                data=data.replaceAll("x","*");
                Context rhino=Context.enter();
                rhino.setOptimizationLevel(-1);
                String finalResult="";
                Scriptable s=rhino.initStandardObjects();
                finalResult=rhino.evaluateString(s,data,"JavaScript",1,null).toString();
                answer.setText(finalResult);
            }
        });

    }
}
